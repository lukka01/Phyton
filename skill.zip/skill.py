file = open("test.txt")
my_data = file.read()
print(my_data)